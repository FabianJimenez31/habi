# API-Habi

API que permite el almacenamiento, consulta y eliminacion de Inmuebles dados los parametros requeridos:

- Los datos del dueño del apartamento, que son: el nombre, teléfono de
contacto y correo.

-  Del inmueble el área, número de habitaciones, precio y dirección que
debe estar en una localidad de una ciudad.

## Base de Datos

Se utiliza el gestor de base de datos MySQL, utilizando debido a la naturaleza de los requerimientos, una sola tabla llamada **Inmuebles**, que tiene los siguientes campos.

- **id** *INT PRIMARY KEY AUTO_INCREMENT UNIQUE NOT NULL*: Numero de Identificacion Unico del Registro
- **propietario_nombre** *VARCHAR(64)*: Nombre Completo del propietario
- **propietario_telefono** *VARCHAR(14)*: Numero Telefonico del propietario
- **propietario_email** *VARCHAR(245)*: Direccion de correo electronico del propietario
- **area** *FLOAT*: Area del inmueble
- **habitaciones** *INT*: Numero de habitaciones
- **precio** *FLOAT*: Precio del Inmueble
- **direccion** *TEXT*: Direccion del Inmueble
- **localidad** *VARCHAR(64)*: Localidad del Inmueble
- **ciudad** *VARCHAR(64)*: Ciudad del Inmueble
- **creacion** *INT*: Fecha de Creacion (Almacenada como UNIX TIMESTAMP en segundos)

Se incluye asi mismo los archivos:

- CreateAdminUser.sql Request para crear un usuario en MySQL
- CreateDatabase.sql  Request para crear una database en MySQL
- Database.sql        Request que se utiliza para la creacion de la tabla 'Inmuebles'

## Configuracion

La API Presente utiliza NodeJS V12+ para realizar las tareas solicitadas, y asi mismo esta realizado para ser ejecutado en un entorno Serverless (Lamba). Fue desarrollado usando el Serveless Framework y el respectivo archivo "serverless.yml" se proporciona.

En caso de dudas en la ejecucion de aplicaciones utilizando el Serverless Framework, se puede consultar la documentacion respectiva en [https://www.serverless.com/framework/docs](https://www.serverless.com/framework/docs)

> **Importante**
Debe configurar sus parametros de conexion a su Base de Datos editando el archivo connection.js con los parametros adecuados en la seccion
```
...
const configDB = {
  host: 'localhost', //<- Host de su servidor MySQL (RDS)
  user: 'database_user', //<- Usuario de acceso a su servidor MySQL (RDS)
  password: 'database_user_password', //<- Contrasena de Seguridad de su servidor MySQL (RDS)
  port: '3306', //<- Puerto de su servidor MySQL (RDS)
  database: 'habi_api', //<- Base de datos a usar dentro de su servidor MySQL (RDS)
  debug: false //<- Cambiar a true para hacer debug de DB
};
...
```

## Deploy

Dependiendo del servicio a utilizar debera configurar los parametros de su Serverless Framework (Perfil AWS,etc). Una vez hecho esto puede probar el servicio usando

```bash
sls deploy
```

Asi mismo si requiere hacer pruebas offline, puede utilizar:
```bash
sls offline
```

## Endpoints Expuestos

La API Expone los siguientes endpoints:

### [POST] /dev/inmuebles

Listado de los Inmuebes, permite filtrar, ordenar y paginar los inmuebles de acuerdo a los parametros requeridos:
- Parametros posibles:
    - *fields*: Array de Strings de los campos a mostrar, en caso de estar vacio se mostraran todos los campos. Valores posibles: "id", "propietario_nombre", "propietario_telefono", "propietario_email", "area", "habitaciones", "precio", "direccion", "localidad", "ciudad", "creacion"

    - *filters*: Array de Objetos con los parametros de filtrado

        - *campo* (obligatorio): Campo sobre el que se aplicara el filtro (string)

        - *tipo* (obligatorio): Tipo de filtro que se aplicara, valores posibles (string):
            - "igual"     Buscar el valor exacto
            - "signo"     Buscar usando un signo de comparacion
            - "parcial"   Buscar parte del contenido del valor del campo
            - "rango"     Buscar entre un rango de valores

        - *signo* (opcional): Solo obligatorio si el tipo de filtro es "signo" (string). Valores posibles: "=","<","<=",">",">="

        - *valor*         Valor con el cual efectuar la busqueda. El tipo de valor puede ser number, string o array. En caso de que el tipo de filtro sea "rango", el valor debe ser un Array que contenga el par [Valor_minimo,Valor_maximo] ambos de tipo numerico. Para los tipos number y string, estos deberan coincidir con el tipo de valor que se encuentra en el campo filtrado (ver Estructura de la base de datos como referencia)

    - *order*: Array de objetos con los paramtros de orden
        - *campo*      Nombre del campo sobre el cual efectuar el ordenamiento (String).
        - *direccion*  Tipo de ordenamiento (string). Valores posibles "asc" para orden ascendente, "desc" para orden descendente

    - *start*: Devolver resultados a partir de este ordenado (int). Equivalente a LIMIT start,length en MySQL.

    - *length*: Numero de resultados devolver (int). Equivalente a LIMIT start,length en MySQL.

La Respuesta cuenta con los siguientes parametros:
   - *total*: Total de Resultados Filtrados (incluye el resultado de filtrar, no solo los que se solicitan en length)
   - *data*: Arreglo de Objetos de Inmuebles con los campos solicitados

Ejemplo de Request:
```json
{
    "fields":["id","propietario_nombre"],
    "filters":[                          
        {
            "campo":"id",
            "tipo":"signo",
            "valor":1,
            "signo":">"
        }
    ],
    "order":[
        {"campo":"propietario_nombre","direccion":"desc"},
        {"campo":"propietario_telefono","direccion":"desc"}
    ],
    "start":1,
    "length":2
}
```

Ejemplo de Respuesta:

```json
{
    "total": 6,
    "data": [
        {
            "id": 4,
            "propietario_nombre": "DEMO2",
            "propietario_telefono": "7757716077",
            "propietario_email": "me@email.com",
            "area": 100,
            "habitaciones": 5,
            "precio": 1500.5,
            "direccion": "CENTRO PRINCIPAL",
            "localidad": "MINI",
            "ciudad": "IBG",
            "creacion": 1638469851
        },
        {
            "id": 5,
            "propietario_nombre": "DEMO2",
            "propietario_telefono": "7757716077",
            "propietario_email": "me@email.com",
            "area": 100,
            "habitaciones": 5,
            "precio": 1500.5,
            "direccion": "CENTRO PRINCIPAL",
            "localidad": "MINI",
            "ciudad": "IBG",
            "creacion": 1638469900
        }
    ]
}
```


### [PUT] /dev/inmuebles

Permite la insercion de uno o mas inmuebles

Los campos en la solicitud son:

- *propietario_nombre* VARCHAR(64) (String) [obligatorio]
- *propietario_telefono* VARCHAR(14) (String) [obligatorio]
- *propietario_email* VARCHAR(245) (String) [obligatorio]
- *area* FLOAT (Number) [obligatorio]
- *habitaciones* INT (Number) [obligatorio]
- *precio* FLOAT (Number) [obligatorio]
- *direccion* TEXT (String) [obligatorio]
- *localidad* VARCHAR(64) (String) [obligatorio]
- *ciudad* VARCHAR(64) (String) [obligatorio]

Se permite enviar un elemento unico un array de elementos

La respuesta contiene los siguientes campos:

- "ErroresFinal" Array de Mensajes de Error, en caso de que haya habido un error en alguno de los registros

- "IdInsertados" Array de Objetos que incluye la posicion del registro insertado y el ID que le fue asignado

Ejemplo de request unica

```json
{
    "propietario_nombre":"DEMO23",
    "propietario_telefono": "7717775939",
    "propietario_email": "me@email.com",
    "area":100,
    "habitaciones":5,
    "precio":1500.50,
    "direccion": "CENTRO PRINCIPAL",
    "localidad":"MINI",
    "ciudad":"IBG"
}
```
Ejemplo de request multiple

```json
[
  {
      "propietario_nombre":"DEMO23",
      "propietario_telefono": "7717775939",
      "propietario_email": "me@email.com",
      "area":100,
      "habitaciones":5,
      "precio":1500.50,
      "direccion": "CENTRO PRINCIPAL",
      "localidad":"MINI",
      "ciudad":"IBG"
  },
  {
      "propietario_nombre":"DEMO3",
      "propietario_telefono": "7759743440",
      "propietario_email": "me2@email.com",
      "area":80,
      "habitaciones":3,
      "precio":15000000,
      "direccion": "CLL 14",
      "localidad":"BGU",
      "ciudad":"TTM"
  }
]
```

Ejemplo de Respuesta

```json
{
    "ErroresFinal": [
      "Campo Nombre de Propietario [propietario_nombre] requerido. Registro 3",
      "Campo Email de Propietario [propietario_email] tipo de valor invalido. Registro 4"
    ],
    "IdInsertados": [
        {
            "registro": 1,
            "id": 9
        },
        {
            "registro": 2,
            "id": 10
        }
    ]
}
```


* [DELETE] /dev/inmuebles/{id}

Elimina el Inmueble cuyo id sea el que se indica en el parametro {id} en la URL

Ejemplo de Respuesta

```json
{
    "res": "Inmueble eliminado correctamente"
}
```

* [GET] /dev/paises

Herramienta solicitada como servicio que permita obtener un listado de países y se lo devuelva al front.

Este endpoint utiliza la libreria npm "countries-list" [https://www.npmjs.com/package/countries-list](https://www.npmjs.com/package/countries-list)

Devuelve el elemento:

```json
{
  "continents": {
    "AF": "Africa",
    "AN": "Antarctica",
    "AS": "Asia",
    "EU": "Europe",
    "NA": "North America",
    "OC": "Oceania",
    "SA": "South America"
  },
  "countries": {
    "AE": {
      "name": "United Arab Emirates",
      "native": "دولة الإمارات العربية المتحدة",
      "phone": "971",
      "continent": "AS",
      "capital": "Abu Dhabi",
      "currency": "AED",
      "languages": [
        "ar"
      ],
      "emoji": "🇦🇪",
      "emojiU": "U+1F1E6 U+1F1EA"
    },
    ...
    "UA": {
      "name": "Ukraine",
      "native": "Україна",
      "phone": "380",
      "continent": "EU",
      "capital": "Kyiv",
      "currency": "UAH",
      "languages": [
        "uk"
      ],
      "emoji": "🇺🇦",
      "emojiU": "U+1F1FA U+1F1E6"
    }
  },
  "languages": {
    "ar": {
      "name": "Arabic",
      "native": "العربية",
      "rtl": 1
    },
    ...
    "uk": {
      "name": "Ukrainian",
      "native": "Українська"
    }
  }
}

```
