const GLOBALAPIENDPOINT = "http://localhost:3000"
