async function APIRequest (endpoint="",method="GET",body=false){
  const fetchoptions = {
    method, // *GET, POST, PUT, DELETE, etc.
    headers: {
      'Content-Type': 'application/json'
    }
  }
  if(body){
    fetchoptions.body= JSON.stringify(body)
  }
  return await fetch(`${GLOBALAPIENDPOINT}${endpoint}`,fetchoptions)
}

function SubmitCreateForm(form){
  const object = {};
  form.forEach(function(value, key){
      if(["area","habitaciones","precio"].includes(key)){
        object[key] = parseFloat(value);
      }else{
        object[key] = value;
      }
  });
  excecuteSubmitCreate(object)
  return false
}

async function excecuteSubmitCreate(data){
  const respuesta = await APIRequest("/dev/inmuebles","PUT",data)
  const final = await respuesta.json()
  document.getElementById("CreationResult").innerHTML = JSON.stringify(final,null,4)
  if(final.ErroresFinal.length<=0){
    document.getElementById("SubmitForm").reset()
  }
  updateListed();
}

document.getElementById("SubmitForm").addEventListener("submit",function(e){
  e.preventDefault()
  e.stopPropagation()
  SubmitCreateForm(new FormData(this))
})

async function updateListed(){
  const respuesta = await APIRequest("/dev/inmuebles","POST",{})
  const final = await respuesta.json()
  document.getElementById("ElementosContainer").innerHTML = final.data.map(drawResult).join("")
}

async function DeleteElementId(id){
  if(confirm(`Eliminar Elemento ${id}`)){
    const respuesta = await APIRequest(`/dev/inmuebles/${id}`,"DELETE")
    const final = await respuesta.json()
    alert(JSON.stringify(final,null,4))
    updateListed();
  }
}

function drawResult(d){
  const llaves = Object.keys(d)
  return `
    <hr>
    <h3>Elemento ID ${d.id} <button onclick="DeleteElementId(${d.id})">&times</button> </h3>
    ${llaves.map(ll=>{
      return ((ll==='creacion')?`<b>${ll}</b>: ${new Date(d[ll]*1000)}`:`<b>${ll}</b>: ${d[ll]}`) + "<br/>"
    }).join("")}
  `
}

async function GetPaises(){
  const respuesta = await APIRequest("/dev/paises","GET")
  const final = await respuesta.json()
  document.getElementById("PaisesContainer").innerHTML = JSON.stringify(final,null,4)
}

updateListed()
GetPaises()
