module.exports = [
  {
    campo:"propietario_nombre",
    etiqueta:"Nombre del Propietario",
    tipo:"text",
    validacion:input=>{
      if(typeof(input)==='string' ){
        const prueba =  String(input).replace(/[^0-9A-Za-z]/g, '');
        if(String(prueba).length<=0  ){
          return false;
        }
        return true;
      }
      return false;
    },
    requerido:true
  },
  {
    campo:"propietario_telefono",
    etiqueta:"Telefono del Propietario",
    tipo:"text",
    validacion:input=>{
      if(typeof(input)==='string' ){
        const prueba =  String(input).replace(/[^0-9]/g, '');
        if(String(prueba)!==String(input) || prueba.length<5 ){
          return false;
        }
        return true;
      }
      return false;
    },
    requerido:true
  },
  {
    campo:"propietario_email",
    etiqueta:"Email del Propietario",
    tipo:"text",
    validacion:email=>{
      if(typeof(email)==='string' ){
        const tester = /^[-!#$%&'*+\/0-9=?A-Z^_a-z{|}~](\.?[-!#$%&'*+\/0-9=?A-Z^_a-z`{|}~])*@[a-zA-Z0-9](-*\.?[a-zA-Z0-9])*\.[a-zA-Z](-?[a-zA-Z0-9])+$/;
        if (!email)
            return false;

        if(email.length>254)
          return false;

        const valid = tester.test(email);
        if(!valid)
          return false;

        // Further checking of some things regex can't handle
        const parts = email.split("@");
        if(parts[0].length>64)
          return false;

        const domainParts = parts[1].split(".");
        if(domainParts.some(function(part) { return part.length>63; }))
          return false;

        return true;
      }
      return false;
    },
    requerido:true
  },
  {
    campo:"area",
    etiqueta:"Area del Inmueble",
    tipo:"float",
    validacion:d=>{
      return d>0;
    },
    requerido:true
  },
  {
    campo:"habitaciones",
    etiqueta:"Numero de habitaciones del Inmueble",
    tipo:"int",
    validacion:d=>{
      return d>0;
    },
    requerido:true
  },
  {
    campo:"precio",
    etiqueta:"Precio del Inmueble",
    tipo:"float",
    validacion:d=>{
      return d>0;
    },
    requerido:true
  },
  {
    campo:"direccion",
    etiqueta:"Direccion del Inmueble",
    tipo:"text",
    validacion:d=>{
      return d.length>0;
    },
    requerido:true
  },
  {
    campo:"localidad",
    etiqueta:"Localidad del Inmueble",
    tipo:"text",
    validacion:d=>{
      return d.length>0;
    },
    requerido:true
  },
  {
    campo:"ciudad",
    etiqueta:"Ciudad del Inmueble",
    tipo:"text",
    validacion:d=>{
      return d.length>0;
    },
    requerido:true
  }
]
