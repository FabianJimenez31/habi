CREATE USER 'database_user'@'%' IDENTIFIED BY 'database_user_password';


grant all privileges on habi_api.* to 'database_user'@'%' with grant option;
