CREATE DATABASE habi_api;
USE habi_api;
