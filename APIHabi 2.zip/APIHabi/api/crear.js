const connection = require('../connection');
const querystring = require('querystring');
const ModeloInmueble = require('../model/inmueble')


module.exports = async (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  let bodyFull = JSON.parse(event['body'])

  if(!(Array.isArray(bodyFull))){
    bodyFull = [JSON.parse(event['body'])]
  }
  const ErroresFinal = []
  const ElementosInsertar = []
  const IdInsertados = []
  bodyFull.forEach((body,i) => {
      const ObjetoInsertar = {
        creacion:Math.floor((new Date()).getTime()/1000)
      }
      let Continuar = true
      const Inserta = {
        registro:i+1,
        tipo:false
      }
      for(let x=0;x<ModeloInmueble.length;x++){
        const c=ModeloInmueble[x]
          if(body[c.campo]){
            if(c.tipo === "float" || c.tipo==="int"){
              if(typeof(body[c.campo])!=='number'){
                ErroresFinal.push(`Campo ${c.etiqueta} [${c.campo}] tipo de valor invalido. Registro ${Inserta.registro}`)
                Continuar = false
              }
            }else if (c.tipo==="text") {
              if(typeof(body[c.campo])!=='string'){
                ErroresFinal.push(`Campo ${c.etiqueta} [${c.campo}] tipo de valor invalido. Registro ${Inserta.registro}`)
                Continuar = false
              }
            }
            if(c.validacion(body[c.campo])!==true){
              ErroresFinal.push(`Campo ${c.etiqueta} [${c.campo}] valor invalido. Registro ${Inserta.registro}`)
              Continuar = false
            }
            if(Continuar){
              if(c.tipo==="float"){
                ObjetoInsertar[c.campo] = parseFloat(body[c.campo])
              }else if(c.tipo==="int"){
                ObjetoInsertar[c.campo] = parseInt(body[c.campo])
              }else if(c.tipo==="text"){
                ObjetoInsertar[c.campo] = String(body[c.campo])
              }
            }
          }else{
            if(c.requerido){
              ErroresFinal.push(`Campo ${c.etiqueta} [${c.campo}] requerido. Registro ${Inserta.registro}`)
              Continuar = false
            }
          }
      }

      if(Continuar===true){
        const Llaves = Object.keys(ObjetoInsertar)
        Inserta.tipo = true
        Inserta.sql = {
          query:`INSERT INTO Inmuebles SET ${(Llaves).map(o=>{return ` ${o} = ?`}).join(",")}`,
          values:Llaves.map(o=>{return ObjetoInsertar[o]})
        }
      }
      ElementosInsertar.push(Inserta)
  });

  for(let i=0;i<ElementosInsertar.length;i++){
    if(ElementosInsertar[i].tipo===true){
      const ResultadoQuery = {}
      try{
        ResultadoQuery.result = await connection.promise().query(ElementosInsertar[i].sql.query,ElementosInsertar[i].sql.values)
      }catch(e){
        ErroresFinal.push(`Error Interno Insertando. Registro ${ElementosInsertar[i].registro}`)
      }
      if(ResultadoQuery.result){
        IdInsertados.push({
          registro:ElementosInsertar[i].registro,
          id:ResultadoQuery.result[0].insertId,
        })
      }
    }
  }

  callback(null, {
    statusCode: 200,
    body: JSON.stringify({
      ErroresFinal,
      IdInsertados
    })
  })
};
