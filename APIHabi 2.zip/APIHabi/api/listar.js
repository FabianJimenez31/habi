const connection = require('../connection');
const querystring = require('querystring');
const ModeloInmueble = require('../model/inmueble')

function parseBodyData(data={}){
    let SQLQuery = "SELECT "
    let SQLCountQuery = "SELECT COUNT(id) as Total FROM Inmuebles "
    const AddedFields = []
    const ReplacedVariables = []
    const OrderFields = []
    const LimitPair = []
    if(data.fields){
      if(Array.isArray(data.fields)){
        ModeloInmueble.forEach(f => {
          if(data.fields.includes(f.campo)){
            AddedFields.push(f.campo)
          }
        });
        if(data.fields.includes("creacion")){
          AddedFields.push("creacion")
        }
        if(data.fields.includes("id")){
          AddedFields.push("id")
        }
      }
    }
    if(AddedFields.length>0){
      SQLQuery+=` ${AddedFields.join(",")} `
    }else{
      SQLQuery+=" * "
      ModeloInmueble.forEach(f => {
        AddedFields.push(f.campo)
      });
      AddedFields.push("creacion")
    }

    SQLQuery+= " FROM Inmuebles "

    if(data.filters){
      if(Array.isArray(data.filters)){
        data.filters.forEach(f => {
          ModeloInmueble.forEach(c => {
            if(c.campo===f.campo && f.valor && f.valor!==""){
              if(f.tipo==="parcial"){
                SQLQuery+=`${(ReplacedVariables.length<=0)?" WHERE ":" AND "} ${f.campo} LIKE ? `
                SQLCountQuery+=`${(ReplacedVariables.length<=0)?" WHERE ":" AND "} ${f.campo} LIKE ? `
                ReplacedVariables.push(`%${f.valor}%`)
              }else if(f.tipo==="igual"){
                SQLQuery+=`${(ReplacedVariables.length<=0)?" WHERE ":" AND "} ${f.campo} = ? `
                SQLCountQuery+=`${(ReplacedVariables.length<=0)?" WHERE ":" AND "} ${f.campo} = ? `
                ReplacedVariables.push(f.valor)
              }else if (f.tipo==="rango") {
                if(Array.isArray(f.valor)){
                  if(f.valor.length===2){
                    SQLQuery+=`${(ReplacedVariables.length<=0)?" WHERE ":" AND "} ${f.campo} >= ? AND ${f.campo} <= ? `
                    SQLCountQuery+=`${(ReplacedVariables.length<=0)?" WHERE ":" AND "} ${f.campo} >= ? AND ${f.campo} <= ? `
                    ReplacedVariables.push(f.valor[0])
                    ReplacedVariables.push(f.valor[1])
                  }
                }
              }else if (f.tipo==="signo") {
                if(f.signo){
                  if(["=","<","<=",">",">="]){
                    SQLQuery+=`${(ReplacedVariables.length<=0)?" WHERE ":" AND "} ${f.campo} ${f.signo} ? `
                    SQLCountQuery+=`${(ReplacedVariables.length<=0)?" WHERE ":" AND "} ${f.campo} ${f.signo} ? `
                    ReplacedVariables.push(f.valor)
                  }
                }
              }
            }
          })
          if(["id","creacion"].includes(f.campo) && f.valor  ){

            if(f.tipo==="igual" && typeof(f.valor)==="number" && f.valor!=="" && f.valor>0){
              SQLQuery+=`${(ReplacedVariables.length<=0)?" WHERE ":" AND "} ${f.campo} = ? `
              SQLCountQuery+=`${(ReplacedVariables.length<=0)?" WHERE ":" AND "} ${f.campo} = ? `
              ReplacedVariables.push(parseInt(f.valor))
            }else if (f.tipo==="rango") {
              if(Array.isArray(f.valor)){
                if(f.valor.length===2){
                  SQLQuery+=`${(ReplacedVariables.length<=0)?" WHERE ":" AND "} ${f.campo} >= ? AND ${f.campo} <= ? `
                  SQLCountQuery+=`${(ReplacedVariables.length<=0)?" WHERE ":" AND "} ${f.campo} >= ? AND ${f.campo} <= ? `
                  ReplacedVariables.push(parseInt(f.valor[0]))
                  ReplacedVariables.push(parseInt(f.valor[1]))
                }
              }
            }else if (f.tipo==="signo" && typeof(f.valor)==="number" && f.valor!=="" && f.valor>0) {
              if(f.signo){
                if(["=","<","<=",">",">="]){
                  SQLQuery+=`${(ReplacedVariables.length<=0)?" WHERE ":" AND "} ${f.campo} ${f.signo} ? `
                  SQLCountQuery+=`${(ReplacedVariables.length<=0)?" WHERE ":" AND "} ${f.campo} ${f.signo} ? `
                  ReplacedVariables.push(parseInt(f.valor))
                }
              }
            }
          }
        })
      }
    }

    //
    if (data.order) {
      if(Array.isArray(data.order)){
        data.order.forEach( o => {
            ModeloInmueble.forEach(f => {
              if(f.campo === o.campo){
                if(o.direccion){
                  if(["asc","desc"].includes(o.direccion.toLowerCase())){
                    SQLQuery+=`${(OrderFields.length<=0)?" ORDER BY ":" , "} ${o.campo} ${o.direccion.toUpperCase()} `
                    OrderFields.push(o.campo)
                  }
                }
              }
            });
            if(["id","creacion"].includes(o.campo) && o.direccion){
              if(["asc","desc"].includes(o.direccion.toLowerCase())){
                SQLQuery+=`${(OrderFields.length<=0)?" ORDER BY ":" , "} ${o.campo} ${o.direccion.toUpperCase()} `
                OrderFields.push(o.campo)
              }
            }
        })
      }
    }



    if(data["length"] && typeof(data.length)==="number" && data.length>0){
      if(data["start"] && typeof(data.start)==="number" && data.start>0){
        LimitPair.push(parseInt(data.start))
      }
      LimitPair.push(parseInt(data.length))
    }
    if(LimitPair.length>0){
      SQLQuery+=` LIMIT ${LimitPair.join(",")} `
    }
    SQLQuery+=";"
    SQLCountQuery+=";"

    return {
      SQLQuery,
      SQLCountQuery,
      ReplacedVariables
    };
  }

  module.exports = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    const body = JSON.parse(event['body'])
    const SQLFull = parseBodyData(body)
    const ResultadoObjetos = await connection.promise().query(SQLFull.SQLQuery,SQLFull.ReplacedVariables)
    const Total = await connection.promise().query(SQLFull.SQLCountQuery,SQLFull.ReplacedVariables)
    callback(null, {
      statusCode: 200,
      body: JSON.stringify({
        total: Total[0][0].Total,
        data:ResultadoObjetos[0]
      })
    })
  };
