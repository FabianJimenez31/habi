const Paises = require('countries-list')

module.exports = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  callback(null, {
    statusCode: 200,
    body: JSON.stringify({
      continents:Paises.continents,
      countries:Paises.countries,
      languages:Paises.languages
    })
  })

};
