const connection = require('../connection');
const querystring = require('querystring');

module.exports = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  if(isNaN(parseInt(event.pathParameters.inmueble_id))){
    callback({
      statusCode: 500,
      body: JSON.stringify({
        res: `Id invalido`
      })
    })
  }else{
    const sql = 'DELETE FROM Inmuebles WHERE id = ?';
    connection.query(sql, [parseInt(event.pathParameters.inmueble_id)], (error, result) => {
      if (error) {
        callback({
          statusCode: 500,
          body: JSON.stringify(error)
        })
      } else {
        callback(null, {
          statusCode: 200,
          body: JSON.stringify({
            res: `Inmueble eliminado correctamente`
          })
        })
      }
    })
  }

};
