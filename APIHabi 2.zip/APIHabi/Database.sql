CREATE TABLE Inmuebles (
    id INT PRIMARY KEY AUTO_INCREMENT UNIQUE NOT NULL,
    propietario_nombre VARCHAR(64),
    propietario_telefono VARCHAR(14),
    propietario_email VARCHAR(245),
    area FLOAT,
    habitaciones INT,
    precio FLOAT,
    direccion TEXT,
    localidad VARCHAR(64),
    ciudad VARCHAR(64),
    creacion INT,
    INDEX localidad(localidad),
    INDEX ciudad(ciudad),
    INDEX creacion(creacion),
    INDEX propietario_nombre(propietario_nombre),
    INDEX propietario_telefono(propietario_telefono),
    INDEX propietario_email(propietario_email)
);
